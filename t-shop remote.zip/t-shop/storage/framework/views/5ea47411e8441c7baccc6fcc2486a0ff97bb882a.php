<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-sm-9 mx-auto">
            <!--product -->
            <div class="product">
                <h4 class="mb-4"><b><?php echo e($title); ?></b></h4>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="<?php echo e(url_images('gambar', $edit->gambar)); ?>" class="img-fluid w-100 mb-3">
                    </div>
                    <div class="col-sm-8 detail-produk">
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>category</b></div>
                            <div class="col-sm-8">
                                <a class="text-produk" href="<?php echo e(url('kategori/'.$edit->id)); ?>">
                                    <?php echo e($edit->nama_kategori); ?>

                                </a>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>product name</b></div>
                            <div class="col-sm-8"><?= $edit->nama_produk;?></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>Selling price</b></div>
                            <div class="col-sm-8 text-success"><h4><b><?= number_format($edit->harga_jual);?>birr,-</b></h4></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b>Discription</b></div>
                            <div class="col-sm-8"><?= $edit->deskripsi;?></div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-4"><b></b></div>
                            <div class="col-sm-8">
                                <a class="btn btn-success btn-md" 
                                    href="https://api.whatsapp.com/send/?phone=<?php echo e($profil_toko->phone); ?>&text=Halo+Admin+Saya+ingin+membeli+produk+<?php echo e(url('produk/'.$edit->id)); ?>" target="_blank" role="button">
                                    <i class="fab fa-whatsapp"></i> Order now    
                                </a>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\t-shop\resources\views/contents/frontend/produk.blade.php ENDPATH**/ ?>