<?php $__env->startSection('content'); ?>
<!-- promosi -->

<!-- end promosi -->
<!-- carausel -->
<div id="carouselId" class="carousel slide" data-bs-ride="carousel">
    
    <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
            <img src="<?php echo e(asset('assets/img/photo1.png')); ?>" class="img-fluid w-100" id="gambar_slider" alt="First slide">
        </div>
        <div class="carousel-item">
            <img src="<?php echo e(asset('assets/img/photo2.png')); ?>" class="img-fluid w-100" id="gambar_slider" alt="Second slide">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselId" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselId" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<div class="container mt-5">
    <div class="row">
        <div class="col-sm-9 mx-auto">
            <!--product -->
            <div class="product">
                <h4 class="mb-4"><b>Recent Products</b></h4>
                <?php echo $__env->make('components.frontend.produk_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- end product -->
            <div class="official mt-3">
                <div class="row">
                    <div class="col-sm-7">
                        <div class="official-content">
                            <h4><b>Offline Stores</b></h4>
                            <p>thi is my offline store located in Adama town Amede Gebeya inside ....</p>
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <img src="<?php echo e(asset('assets/img/photo1 - Copy.png')); ?>" class="img-fluid w-100">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\t-shop\resources\views/contents/frontend/home.blade.php ENDPATH**/ ?>